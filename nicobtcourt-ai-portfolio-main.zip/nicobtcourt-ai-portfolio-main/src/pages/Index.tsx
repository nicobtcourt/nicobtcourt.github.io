import Hero from "@/components/Hero";
import Services from "@/components/Services";
import UseCases from "@/components/UseCases";
import Process from "@/components/Process";
import Stats from "@/components/Stats";
import TechStack from "@/components/TechStack";
import FAQ from "@/components/FAQ";
import CTA from "@/components/CTA";
import Footer from "@/components/Footer";

const Index = () => {
  return (
    <div className="min-h-screen">
      <Hero />
      <Services />
      <UseCases />
      <Process />
      <Stats />
      <TechStack />
      <FAQ />
      <CTA />
      <Footer />
    </div>
  );
};

export default Index;
