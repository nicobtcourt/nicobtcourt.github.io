import { Button } from "@/components/ui/button";
import { ArrowRight, Zap } from "lucide-react";
import heroImage from "@/assets/hero-image.jpg";

const Hero = () => {
  return (
    <section className="relative min-h-screen flex items-center justify-center overflow-hidden bg-gradient-hero">
      {/* Background decorative elements */}
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute top-20 left-10 w-72 h-72 bg-primary/10 rounded-full blur-3xl animate-pulse"></div>
        <div className="absolute bottom-20 right-10 w-96 h-96 bg-secondary/10 rounded-full blur-3xl animate-pulse" style={{ animationDelay: '1s' }}></div>
      </div>

      <div className="container mx-auto px-4 py-20 relative z-10">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          {/* Left content */}
          <div className="space-y-8 animate-fade-in-up">
            {/* Badge */}
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-primary/10 border border-primary/20">
              <Zap className="w-4 h-4 text-primary" />
              <span className="text-sm font-medium text-primary">Setup en 48 horas</span>
            </div>

            {/* Headline */}
            <h1 className="text-5xl lg:text-7xl font-heading font-bold leading-tight">
              Automatiza tu atención al cliente con{" "}
              <span className="gradient-text">IA que realmente entiende</span>
            </h1>

            {/* Subheadline */}
            <p className="text-xl lg:text-2xl text-muted-foreground">
              Responde en WhatsApp, Instagram y Messenger automáticamente. 24/7.
            </p>

            {/* CTAs */}
            <div className="flex flex-col sm:flex-row gap-4">
              <Button 
                size="lg" 
                className="text-lg px-8 py-6 bg-gradient-cta hover:shadow-primary transition-all duration-300 hover:scale-105"
              >
                Agendar Demo Gratis
                <ArrowRight className="ml-2 w-5 h-5" />
              </Button>
              <Button 
                size="lg" 
                variant="outline" 
                className="text-lg px-8 py-6 border-2 hover:bg-primary/5"
              >
                Ver Cómo Funciona
              </Button>
            </div>

            {/* Trust indicators */}
            <div className="flex items-center gap-6 text-sm text-muted-foreground pt-4">
              <div className="flex items-center gap-2">
                <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></div>
                <span>Sin tarjeta de crédito</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></div>
                <span>Cancela cuando quieras</span>
              </div>
            </div>
          </div>

          {/* Right image */}
          <div className="relative animate-fade-in-up" style={{ animationDelay: '0.2s' }}>
            <div className="relative rounded-2xl overflow-hidden shadow-glow">
              <img 
                src={heroImage} 
                alt="AI chatbot interface" 
                className="w-full h-auto"
              />
              {/* Floating stats cards */}
              <div className="absolute top-8 right-8 glass rounded-lg p-4 animate-fade-in-up" style={{ animationDelay: '0.4s' }}>
                <div className="text-sm text-muted-foreground">Tiempo de respuesta</div>
                <div className="text-2xl font-bold text-primary">&lt;10 seg</div>
              </div>
              <div className="absolute bottom-8 left-8 glass rounded-lg p-4 animate-fade-in-up" style={{ animationDelay: '0.6s' }}>
                <div className="text-sm text-muted-foreground">Resolución automática</div>
                <div className="text-2xl font-bold text-secondary">95%</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Hero;
