import { Card, CardContent } from "@/components/ui/card";
import { Shield, Database, Cpu, Zap } from "lucide-react";

const technologies = [
  {
    icon: Cpu,
    name: "OpenAI GPT-4",
    description: "Modelo de lenguaje más avanzado"
  },
  {
    icon: Database,
    name: "RAG Technology",
    description: "Retrieval Augmented Generation"
  },
  {
    icon: Zap,
    name: "API Integrations",
    description: "WhatsApp, Meta Graph API"
  },
  {
    icon: Shield,
    name: "Enterprise Security",
    description: "SOC 2 & GDPR compliant"
  }
];

const TechStack = () => {
  return (
    <section className="py-20 px-4 bg-muted/30">
      <div className="container mx-auto">
        <div className="text-center mb-16">
          <h2 className="text-4xl lg:text-5xl font-heading font-bold mb-4">
            Tecnología de <span className="gradient-text">última generación</span>
          </h2>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            Construido sobre los mejores servicios y frameworks del mercado
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
          {technologies.map((tech, index) => (
            <Card 
              key={index}
              className="border-2 hover:border-primary/50 transition-all duration-300 hover-scale group"
            >
              <CardContent className="p-6 text-center">
                <div className="inline-flex p-4 rounded-2xl bg-gradient-primary mb-4 group-hover:scale-110 transition-transform duration-300">
                  <tech.icon className="w-8 h-8 text-white" />
                </div>
                <h3 className="font-heading font-bold text-lg mb-2">{tech.name}</h3>
                <p className="text-sm text-muted-foreground">{tech.description}</p>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Security badges */}
        <div className="mt-12 flex flex-wrap justify-center items-center gap-8 text-muted-foreground">
          <div className="flex items-center gap-2">
            <Shield className="w-5 h-5" />
            <span className="font-semibold">SOC 2 Type II</span>
          </div>
          <div className="flex items-center gap-2">
            <Shield className="w-5 h-5" />
            <span className="font-semibold">GDPR Compliant</span>
          </div>
          <div className="flex items-center gap-2">
            <Shield className="w-5 h-5" />
            <span className="font-semibold">ISO 27001</span>
          </div>
          <div className="flex items-center gap-2">
            <Shield className="w-5 h-5" />
            <span className="font-semibold">256-bit Encryption</span>
          </div>
        </div>
      </div>
    </section>
  );
};

export default TechStack;
