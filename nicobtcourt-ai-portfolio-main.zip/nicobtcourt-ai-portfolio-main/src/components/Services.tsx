import { Card, CardContent } from "@/components/ui/card";
import { MessageSquare, Bot, Clock } from "lucide-react";

const services = [
  {
    icon: MessageSquare,
    title: "Atención Multi-Canal",
    description: "WhatsApp, Instagram y Facebook Messenger. Un solo panel, todas tus conversaciones.",
    color: "text-primary"
  },
  {
    icon: Bot,
    title: "IA que Aprende",
    description: "RAG avanzado que entiende contexto y se integra con tu inventario en tiempo real.",
    color: "text-secondary"
  },
  {
    icon: Clock,
    title: "Disponibilidad Total",
    description: "Tu asistente nunca duerme. Respuestas instantáneas a cualquier hora.",
    color: "text-primary"
  }
];

const Services = () => {
  return (
    <section className="py-20 px-4">
      <div className="container mx-auto">
        <div className="text-center mb-16 animate-fade-in-up">
          <h2 className="text-4xl lg:text-5xl font-heading font-bold mb-4">
            Todo lo que necesitas en{" "}
            <span className="gradient-text">un solo lugar</span>
          </h2>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            Conecta todos tus canales de comunicación y deja que la IA se encargue del resto
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-8">
          {services.map((service, index) => (
            <Card 
              key={index} 
              className="border-2 hover:border-primary/50 transition-all duration-300 hover-scale hover:shadow-card group"
              style={{ animationDelay: `${index * 0.1}s` }}
            >
              <CardContent className="p-8 text-center">
                <div className={`inline-flex p-4 rounded-2xl bg-primary/10 mb-6 ${service.color} group-hover:scale-110 transition-transform duration-300`}>
                  <service.icon className="w-8 h-8" />
                </div>
                <h3 className="text-2xl font-heading font-bold mb-4">{service.title}</h3>
                <p className="text-muted-foreground leading-relaxed">{service.description}</p>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Services;
