import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";

const faqs = [
  {
    question: "¿Qué canales de comunicación soportan?",
    answer: "Actualmente soportamos WhatsApp Business API, Instagram Direct Messages y Facebook Messenger. Estamos trabajando en agregar más canales como Telegram y SMS."
  },
  {
    question: "¿Cuánto tiempo toma la implementación?",
    answer: "El proceso completo, desde la consulta inicial hasta el lanzamiento, toma aproximadamente 48 horas. Esto incluye la configuración de canales, entrenamiento de la IA con tu información y pruebas de calidad."
  },
  {
    question: "¿Se integra con mi sistema actual?",
    answer: "Sí, nuestra solución se integra fácilmente con la mayoría de CRMs, plataformas de e-commerce y sistemas de gestión. Trabajamos con APIs estándar y podemos crear integraciones personalizadas según tus necesidades."
  },
  {
    question: "¿Qué pasa si el bot no sabe responder?",
    answer: "Si la IA no tiene certeza sobre una respuesta, automáticamente escala la conversación a un agente humano. Además, el sistema aprende continuamente de cada interacción para mejorar sus respuestas."
  },
  {
    question: "¿Cómo se entrena la IA con mi información?",
    answer: "Utilizamos tecnología RAG (Retrieval Augmented Generation) que permite entrenar la IA con tus documentos, FAQs, catálogos de productos e información de inventario. El proceso es guiado y no requiere conocimientos técnicos."
  },
  {
    question: "¿Puedo personalizar las respuestas del bot?",
    answer: "Absolutamente. Puedes definir el tono de voz, el estilo de comunicación y las respuestas específicas para diferentes situaciones. También puedes actualizar la información en cualquier momento."
  }
];

const FAQ = () => {
  return (
    <section className="py-20 px-4">
      <div className="container mx-auto max-w-4xl">
        <div className="text-center mb-16">
          <h2 className="text-4xl lg:text-5xl font-heading font-bold mb-4">
            Preguntas <span className="gradient-text">frecuentes</span>
          </h2>
          <p className="text-xl text-muted-foreground">
            Todo lo que necesitas saber sobre nuestro servicio
          </p>
        </div>

        <Accordion type="single" collapsible className="space-y-4">
          {faqs.map((faq, index) => (
            <AccordionItem 
              key={index} 
              value={`item-${index}`}
              className="border-2 border-border rounded-xl px-6 hover:border-primary/50 transition-colors duration-300"
            >
              <AccordionTrigger className="text-left font-heading font-semibold text-lg hover:text-primary py-6">
                {faq.question}
              </AccordionTrigger>
              <AccordionContent className="text-muted-foreground leading-relaxed pb-6">
                {faq.answer}
              </AccordionContent>
            </AccordionItem>
          ))}
        </Accordion>
      </div>
    </section>
  );
};

export default FAQ;
