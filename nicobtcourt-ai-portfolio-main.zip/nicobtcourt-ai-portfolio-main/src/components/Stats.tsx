const stats = [
  {
    value: "95%",
    label: "de consultas resueltas automáticamente",
    icon: "⚡"
  },
  {
    value: "<10 seg",
    label: "tiempo promedio de respuesta",
    icon: "⏱️"
  },
  {
    value: "70%",
    label: "reducción en costos de soporte",
    icon: "💰"
  },
  {
    value: "24/7",
    label: "disponibilidad sin días libres",
    icon: "🌙"
  }
];

const Stats = () => {
  return (
    <section className="py-20 px-4 bg-gradient-primary relative overflow-hidden">
      {/* Decorative elements */}
      <div className="absolute inset-0 opacity-10">
        <div className="absolute top-0 left-1/4 w-96 h-96 bg-white rounded-full blur-3xl"></div>
        <div className="absolute bottom-0 right-1/4 w-96 h-96 bg-white rounded-full blur-3xl"></div>
      </div>

      <div className="container mx-auto relative z-10">
        <div className="text-center mb-16">
          <h2 className="text-4xl lg:text-5xl font-heading font-bold mb-4 text-white">
            Resultados que hablan por sí solos
          </h2>
          <p className="text-xl text-white/80 max-w-2xl mx-auto">
            Métricas reales de nuestros clientes
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
          {stats.map((stat, index) => (
            <div 
              key={index}
              className="text-center glass rounded-2xl p-8 hover-scale transition-all duration-300 border border-white/20"
            >
              <div className="text-5xl mb-4">{stat.icon}</div>
              <div className="text-5xl lg:text-6xl font-bold text-white mb-3 font-heading">
                {stat.value}
              </div>
              <div className="text-white/80 text-lg">
                {stat.label}
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Stats;
