import { Calendar, Settings, GraduationCap, Rocket } from "lucide-react";

const steps = [
  {
    icon: Calendar,
    title: "Consulta",
    description: "Agenda una llamada de 30 min",
    number: "01"
  },
  {
    icon: Settings,
    title: "Configuración",
    description: "Conectamos tus canales y datos",
    number: "02"
  },
  {
    icon: GraduationCap,
    title: "Entrenamiento",
    description: "La IA aprende tu negocio",
    number: "03"
  },
  {
    icon: Rocket,
    title: "Lanzamiento",
    description: "En vivo en 48 horas",
    number: "04"
  }
];

const Process = () => {
  return (
    <section className="py-20 px-4">
      <div className="container mx-auto">
        <div className="text-center mb-16">
          <h2 className="text-4xl lg:text-5xl font-heading font-bold mb-4">
            Cómo <span className="gradient-text">funciona</span>
          </h2>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            De la consulta al lanzamiento en tiempo récord
          </p>
        </div>

        <div className="relative">
          {/* Timeline line */}
          <div className="hidden lg:block absolute top-1/2 left-0 right-0 h-0.5 bg-gradient-to-r from-primary via-secondary to-primary transform -translate-y-1/2"></div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8 relative">
            {steps.map((step, index) => (
              <div 
                key={index} 
                className="relative group"
              >
                {/* Step card */}
                <div className="relative bg-background border-2 border-border rounded-2xl p-6 hover:border-primary/50 transition-all duration-300 hover-scale hover:shadow-card">
                  {/* Step number */}
                  <div className="absolute -top-6 left-6 w-12 h-12 rounded-full bg-gradient-primary flex items-center justify-center text-white font-bold text-lg shadow-primary">
                    {step.number}
                  </div>

                  {/* Icon */}
                  <div className="mt-6 mb-4 inline-flex p-3 rounded-xl bg-primary/10 text-primary group-hover:scale-110 transition-transform duration-300">
                    <step.icon className="w-6 h-6" />
                  </div>

                  {/* Content */}
                  <h3 className="text-xl font-heading font-bold mb-2">{step.title}</h3>
                  <p className="text-muted-foreground">{step.description}</p>
                </div>

                {/* Connector arrow (desktop) */}
                {index < steps.length - 1 && (
                  <div className="hidden lg:block absolute top-1/2 -right-4 w-8 h-8 transform -translate-y-1/2 z-10">
                    <div className="w-0 h-0 border-t-8 border-t-transparent border-b-8 border-b-transparent border-l-8 border-l-primary"></div>
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default Process;
