import { Card, CardContent } from "@/components/ui/card";
import { Package, Briefcase, Target, TrendingUp } from "lucide-react";

const useCases = [
  {
    icon: Package,
    title: "Gestión de Inventario",
    description: "Consultas automáticas de stock y disponibilidad en tiempo real",
    gradient: "from-primary/10 to-primary/5"
  },
  {
    icon: Briefcase,
    title: "Generación de Leads",
    description: "Calificación automática 24/7 para tu equipo de ventas",
    gradient: "from-secondary/10 to-secondary/5"
  },
  {
    icon: Target,
    title: "Soporte Técnico",
    description: "Resolución de dudas frecuentes sin intervención humana",
    gradient: "from-primary/10 to-primary/5"
  },
  {
    icon: TrendingUp,
    title: "Ventas Automatizadas",
    description: "Cierra ventas mientras duermes con seguimiento inteligente",
    gradient: "from-secondary/10 to-secondary/5"
  }
];

const UseCases = () => {
  return (
    <section className="py-20 px-4 bg-muted/30">
      <div className="container mx-auto">
        <div className="text-center mb-16">
          <h2 className="text-4xl lg:text-5xl font-heading font-bold mb-4">
            Casos de uso que{" "}
            <span className="gradient-text">transforman negocios</span>
          </h2>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            Automatiza procesos clave y escala tu negocio sin límites
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
          {useCases.map((useCase, index) => (
            <Card 
              key={index} 
              className={`border-0 hover-scale transition-all duration-300 bg-gradient-to-br ${useCase.gradient} hover:shadow-card group overflow-hidden relative`}
            >
              <CardContent className="p-6 relative z-10">
                <div className="mb-4 inline-flex p-3 rounded-xl bg-background/50 backdrop-blur group-hover:scale-110 transition-transform duration-300">
                  <useCase.icon className="w-6 h-6 text-primary" />
                </div>
                <h3 className="text-xl font-heading font-bold mb-3">{useCase.title}</h3>
                <p className="text-sm text-muted-foreground leading-relaxed">{useCase.description}</p>
              </CardContent>
              {/* Decorative element */}
              <div className="absolute -bottom-10 -right-10 w-32 h-32 bg-primary/5 rounded-full blur-2xl group-hover:bg-primary/10 transition-colors duration-300"></div>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
};

export default UseCases;
